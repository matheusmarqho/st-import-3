import React, { useState, useEffect } from 'react';
import { Product, Sale, ShopSettings } from '../types';
import { ShoppingBag, ArrowRight, User, Phone, DollarSign, Layers, CheckCircle } from 'lucide-react';

interface VendasTabProps {
  products: Product[];
  shopSettings: ShopSettings;
  onAddSale: (sale: Omit<Sale, 'id' | 'timestamp'>) => void;
  onShowReceipt: (sale: Sale) => void;
}

export default function VendasTab({ products, shopSettings, onAddSale, onShowReceipt }: VendasTabProps) {
  const [selectedProductId, setSelectedProductId] = useState('');
  const [soldPrice, setSoldPrice] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(1);
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');

  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Find selected product information
  const selectedProduct = products.find(p => p.id === selectedProductId);

  // Automatically update suggested sold price when product selection changes
  useEffect(() => {
    if (selectedProduct) {
      setSoldPrice(selectedProduct.minSellPrice);
      // Make sure quantity isn't higher than stock
      if (quantity > selectedProduct.quantity) {
        setQuantity(Math.max(1, selectedProduct.quantity));
      }
    } else {
      setSoldPrice(0);
    }
  }, [selectedProductId]);

  const handleConfirmSale = (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    if (!selectedProductId) {
      setMessage({ type: 'error', text: 'Selecione um produto' });
      return;
    }

    if (!selectedProduct) {
      setMessage({ type: 'error', text: 'Produto não encontrado' });
      return;
    }

    if (quantity <= 0) {
      setMessage({ type: 'error', text: 'A quantidade deve ser maior que zero' });
      return;
    }

    if (selectedProduct.quantity < quantity) {
      setMessage({ type: 'error', text: `Estoque insuficiente! Apenas ${selectedProduct.quantity} unidades disponíveis.` });
      return;
    }

    if (soldPrice < selectedProduct.minSellPrice) {
      const confirmLowPrice = window.confirm(
        `Atenção: O valor de venda digitado (${soldPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}) é menor do que o Preço Mínimo definido (${selectedProduct.minSellPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}). Deseja continuar mesmo assim?`
      );
      if (!confirmLowPrice) return;
    }

    // Prepare sale data
    const saleData = {
      productId: selectedProductId,
      productName: selectedProduct.name,
      quantity: Number(quantity),
      soldPrice: Number(soldPrice),
      clientName: clientName.trim() || 'Consumidor Final',
      clientPhone: clientPhone.trim() || 'N/A'
    };

    // Callback to add sale (this will trigger stock reduction in App.tsx)
    // To allow instant receipt view, we return/create the full sale object
    const createdSaleId = Math.random().toString(36).substring(2, 9).toUpperCase();
    const createdSale: Sale = {
      id: createdSaleId,
      timestamp: new Date().toISOString(),
      ...saleData
    };

    onAddSale(saleData);

    setMessage({
      type: 'success',
      text: `Venda de "${selectedProduct.name}" com sucesso! Estoque atualizado.`
    });

    // Clear form states
    setSelectedProductId('');
    setQuantity(1);
    setSoldPrice(0);
    setClientName('');
    setClientPhone('');

    // Trigger showing receipt immediately so the user can share it
    setTimeout(() => {
      onShowReceipt(createdSale);
    }, 1200);
  };

  return (
    <div className="space-y-6" id="vendas-tab">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-800">Registrar Venda</h2>
        <p className="text-sm text-slate-500">Selecione o produto, preencha as informações do cliente e confirme a operação.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="vendas-layout-grid">
        
        {/* Form panel */}
        <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.015)] border border-[#E5E9EB]/65 p-6 lg:col-span-2">
          <form onSubmit={handleConfirmSale} className="space-y-5">
            
            {/* Step 1: Select Product */}
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">1. Selecionar Produto do Estoque *</label>
              <select
                required
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all cursor-pointer"
              >
                <option value="">-- Escolha um produto --</option>
                {products.map(p => (
                  <option 
                    key={p.id} 
                    value={p.id} 
                    disabled={p.quantity <= 0}
                  >
                    {p.name} {p.quantity <= 0 ? '(Sem Estoque)' : `(${p.quantity} unidades em estoque)`}
                  </option>
                ))}
              </select>
            </div>

            {/* Step 2: Sale Values */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">2. Quantidade à Vender *</label>
                <input
                  type="number"
                  required
                  min="1"
                  max={selectedProduct ? selectedProduct.quantity : undefined}
                  value={quantity}
                  onChange={(e) => {
                    const val = Math.max(1, parseInt(e.target.value) || 1);
                    if (selectedProduct && val > selectedProduct.quantity) {
                      setQuantity(selectedProduct.quantity);
                    } else {
                      setQuantity(val);
                    }
                  }}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all"
                />
                {selectedProduct && (
                  <p className="text-xs text-slate-400 mt-1">Disponível em estoque: {selectedProduct.quantity} unidades</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">3. Preço Unitário Unitário (R$) *</label>
                <input
                  type="number"
                  required
                  min="0.01"
                  step="0.01"
                  value={soldPrice || ''}
                  onChange={(e) => setSoldPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                  placeholder="0,00"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all font-mono"
                />
                {selectedProduct && (
                  <p className="text-xs text-slate-400 mt-1">Preço Mínimo Definido: {selectedProduct.minSellPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                )}
              </div>
            </div>

            {/* Step 3: Client Details */}
            <div className="border-t border-slate-100 pt-5 space-y-4">
              <h3 className="block text-xs font-bold text-slate-500 uppercase tracking-wider">4. Dados do Cliente (Opcional - Para Cupom)</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400 pointer-events-none">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    placeholder="Nome do Cliente"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all"
                  />
                </div>

                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400 pointer-events-none">
                    <Phone className="w-4 h-4" />
                  </span>
                  <input
                    type="tel"
                    placeholder="Telefone do Cliente (Ex: 11 99999-9999)"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Notifications */}
            {message && (
              <div className={`p-4 rounded-xl flex items-center gap-2.5 text-sm font-medium ${
                message.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : 'bg-rose-50 text-rose-800 border border-rose-100'
              }`}>
                {message.type === 'success' && <CheckCircle className="w-5 h-5 flex-shrink-0 text-emerald-600" />}
                <span>{message.text}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl px-5 py-3 font-bold transition text-sm cursor-pointer shadow-sm mt-6"
              id="btn-confirm-sale"
            >
              <ShoppingBag className="w-4.5 h-4.5" />
              Confirmar Venda
            </button>

          </form>
        </div>

        {/* Live Calculation / Review Panel */}
        <div className="space-y-6">
          <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-sm border border-slate-800">
            <h3 className="font-bold text-base mb-4 tracking-tight flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400" />
              Resumo da Transação
            </h3>
            
            <div className="space-y-3.5 divide-y divide-slate-800 text-sm font-mono pb-2">
              <div className="flex justify-between text-slate-400">
                <span>Produto:</span>
                <span className="text-white text-right max-w-[150px] truncate">{selectedProduct ? selectedProduct.name : 'Nenhum'}</span>
              </div>
 
              <div className="flex justify-between text-slate-400 pt-3">
                <span>Custo Unitário:</span>
                <span className="text-white">
                  {selectedProduct ? selectedProduct.costPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'R$ 0,00'}
                </span>
              </div>
 
              <div className="flex justify-between text-slate-400 pt-3">
                <span>Vendido por (Unit.):</span>
                <span className="text-emerald-400 font-bold">
                  {soldPrice ? soldPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'R$ 0,00'}
                </span>
              </div>
 
              <div className="flex justify-between text-slate-400 pt-3">
                <span>Quantidade:</span>
                <span className="text-white font-bold">{quantity}x</span>
              </div>
 
              <div className="flex justify-between text-slate-400 pt-3 text-base">
                <span className="text-white font-bold">Valor Total Geral:</span>
                <span className="text-emerald-400 font-extrabold">
                  {(soldPrice * quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
              </div>
 
              {selectedProduct && (
                <div className="flex justify-between text-slate-400 pt-3">
                  <span>Lucro Estimado (CMV):</span>
                  <span className="text-indigo-455 font-bold text-indigo-400">
                    {((soldPrice - selectedProduct.costPrice) * quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
              )}
            </div>
 
            <div className="mt-6 p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400 leading-relaxed">
              💡 Confirmar a venda irá automaticamente reduzir <span className="text-white font-semibold font-mono">{quantity}</span> unidade(s) do estoque e registrar a transação no seu histórico financeiro.
            </div>
          </div>
 
          {/* Quick Shop settings snippet */}
          <div className="bg-white rounded-3xl p-5 shadow-[0_8px_30px_rgb(0,0,0,0.015)] border border-[#E5E9EB]/65 flex flex-col gap-2.5">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Configuração do Emissor</h4>
            <div className="text-xs space-y-1 text-slate-600">
              <p>📍 <strong>Nome da Loja no Cupom:</strong></p>
              <p className="text-slate-800 font-medium pb-2">{shopSettings.shopName}</p>
              <p>📞 <strong>Telefone Cadastrado:</strong></p>
              <p className="text-slate-800 font-medium">{shopSettings.shopPhone}</p>
            </div>
            <p className="text-[10px] text-slate-400 italic mt-1">Altere esses dados na aba "Histórico" para editar o cabeçalho dos cupons.</p>
          </div>
        </div>

      </div>
    </div>
  );
}
