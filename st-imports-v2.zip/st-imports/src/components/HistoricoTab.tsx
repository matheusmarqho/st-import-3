import React, { useState } from 'react';
import { Sale, ShopSettings } from '../types';
import { FileText, Printer, Check, Clipboard, Search, Edit, X, Phone, Trash, Share2 } from 'lucide-react';

interface HistoricoTabProps {
  sales: Sale[];
  shopSettings: ShopSettings;
  onUpdateShopSettings: (settings: ShopSettings) => void;
  selectedReceiptSale: Sale | null;
  onCloseReceipt: () => void;
  onOpenReceipt: (sale: Sale) => void;
  onDeleteSale: (id: string) => void;
}

export default function HistoricoTab({
  sales,
  shopSettings,
  onUpdateShopSettings,
  selectedReceiptSale,
  onCloseReceipt,
  onOpenReceipt,
  onDeleteSale
}: HistoricoTabProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [saleToDelete, setSaleToDelete] = useState<Sale | null>(null);
  
  // Settings edit states
  const [isEditingSettings, setIsEditingSettings] = useState(false);
  const [shopName, setShopName] = useState(shopSettings.shopName);
  const [shopPhone, setShopPhone] = useState(shopSettings.shopPhone);
  const [cnpj, setCnpj] = useState(shopSettings.cnpj || '');
  const [address, setAddress] = useState(shopSettings.address || '');

  const filteredSales = sales.filter(s =>
    s.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.clientName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateShopSettings({
      shopName: shopName.trim() || 'ST Imports',
      shopPhone: shopPhone.trim() || '(11) 93322-1100',
      cnpj: cnpj.trim() || '12.345.678/0001-90',
      address: address.trim() || 'Av. Paulista, 1000 - Bela Vista, São Paulo - SP'
    });
    setIsEditingSettings(false);
  };

  // Helper to format date nicely
  const formatDate = (isoString: string) => {
    const d = new Date(isoString);
    return `${d.toLocaleDateString('pt-BR')} ${d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
  };

  // Format WhatsApp Share text
  const getWhatsAppShareUrl = (sale: Sale) => {
    const d = new Date(sale.timestamp);
    const dateStr = d.toLocaleDateString('pt-BR');
    const timeStr = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    const text = `----------------------------------------
        *${shopSettings.shopName.toUpperCase()}*
     _${shopSettings.address || ''}_
     CNPJ: ${shopSettings.cnpj || 'XX.XXX.XXX/XXXX-XX'}
----------------------------------------
*RECIBO DE VENDA*
*Data:* ${dateStr}   *Hora:* ${timeStr}

*Cliente:* ${sale.clientName}
*Telefone:* ${sale.clientPhone || 'N/A'}
----------------------------------------
*PRODUTO*              *QTD*    *VALOR*
${sale.productName}     ${sale.quantity}     R$ ${sale.soldPrice.toFixed(2)}
----------------------------------------
*TOTAL:*                       R$ ${(sale.soldPrice * sale.quantity).toFixed(2)}
----------------------------------------
_Obrigado pela preferência!_
     *${shopSettings.shopName}*
----------------------------------------`;
    return `https://wa.me/?text=${encodeURIComponent(text)}`;
  };

  // Generate plain text version of Cupom for WhatsApp sharing
  const getShareableText = (sale: Sale) => {
    return `*CUPOM FISCAL SIMPLIFICADO*\n=========================\n*LOJA:* ${shopSettings.shopName}\n*CONTATO:* ${shopSettings.shopPhone}\n=========================\n*DATA:* ${formatDate(sale.timestamp)}\n*CUPOM ID:* #${sale.id}\n-------------------------\n*CLIENTE:* ${sale.clientName}\n*TELEFONE:* ${sale.clientPhone}\n=========================\n*PRODUTO:* ${sale.productName}\n*QUANTIDADE:* ${sale.quantity}x\n*SUBTOTAL:* ${(sale.soldPrice * sale.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}\n=========================\n_Obrigado pela preferência!_`;
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleDirectPrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6" id="historico-tab">
      
      {/* Header and customizable settings toggle */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800">Histórico de Vendas</h2>
          <p className="text-sm text-slate-500">Veja de forma cronológica todas as vendas feitas e gere cupons fiscais.</p>
        </div>
        
        {/* Customizable Shop Header Box */}
        <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-xs max-w-sm w-full md:w-auto">
          {isEditingSettings ? (
            <form onSubmit={handleSaveSettings} className="space-y-2.5 max-w-sm">
              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-0.5">Nome da Loja</label>
                <input
                  type="text"
                  placeholder="Nome da Loja"
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-600"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 block mb-0.5">Telefone</label>
                  <input
                    type="tel"
                    placeholder="Telefone"
                    value={shopPhone}
                    onChange={(e) => setShopPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 block mb-0.5">CNPJ</label>
                  <input
                    type="text"
                    placeholder="CNPJ"
                    value={cnpj}
                    onChange={(e) => setCnpj(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-600 font-mono"
                  />
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-0.5">Endereço Completo</label>
                <input
                  type="text"
                  placeholder="Endereço da Loja"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-600"
                />
              </div>
              <div className="flex gap-2 justify-end pt-1">
                <button
                  type="button"
                  onClick={() => setIsEditingSettings(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg px-2.5 py-1 text-xs font-semibold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-3 py-1 text-xs font-semibold cursor-pointer"
                >
                  Salvar
                </button>
              </div>
            </form>
          ) : (
            <div className="flex items-start justify-between gap-4" id="settings-view-container">
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Dados do Emissor (Cupom)</span>
                <p className="text-sm font-bold text-slate-800 leading-tight">{shopSettings.shopName}</p>
                <p className="text-xs text-slate-500 font-medium flex items-center gap-1">
                  <Phone className="w-3 h-3 text-slate-400" />
                  {shopSettings.shopPhone}
                </p>
                {shopSettings.cnpj && (
                  <p className="text-[10px] font-mono text-slate-400">CNPJ: {shopSettings.cnpj}</p>
                )}
                {shopSettings.address && (
                  <p className="text-[10px] text-slate-400 leading-tight italic max-w-[240px] break-words">{shopSettings.address}</p>
                )}
              </div>
              <button
                onClick={() => {
                  setShopName(shopSettings.shopName);
                  setShopPhone(shopSettings.shopPhone);
                  setCnpj(shopSettings.cnpj || '');
                  setAddress(shopSettings.address || '');
                  setIsEditingSettings(true);
                }}
                className="text-slate-500 hover:text-slate-800 hover:bg-slate-50 rounded-lg p-2 transition cursor-pointer self-start"
                title="Editar Configurações da Loja"
              >
                <Edit className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400">
          <Search className="w-4 h-4" />
        </span>
        <input
          type="text"
          placeholder="Buscar venda por produto ou nome do cliente..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all"
        />
      </div>

      {/* Table representing logs */}
      <div className="bg-white border border-[#E5E9EB]/65 rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.015)] overflow-hidden" id="sales-history-table">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 border-b border-slate-100 text-xs font-bold uppercase tracking-wider font-sans">
                <th className="px-6 py-4">Data e Hora</th>
                <th className="px-6 py-4">Produto</th>
                <th className="px-6 py-4">Qtd. Venda</th>
                <th className="px-6 py-4">Valor Unitário</th>
                <th className="px-6 py-4">Total Pago</th>
                <th className="px-6 py-4">Cliente</th>
                <th className="px-6 py-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredSales.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    Nenhuma venda encontrada para os critérios de busca.
                  </td>
                </tr>
              ) : (
                filteredSales.slice().reverse().map(sale => (
                  <tr key={sale.id} className="hover:bg-slate-50/50 transition">
                    <td className="px-6 py-4 font-mono text-xs text-slate-500">
                      {formatDate(sale.timestamp)}
                    </td>
                    <td className="px-6 py-4 font-semibold text-slate-800">
                      {sale.productName}
                    </td>
                    <td className="px-6 py-4 font-semibold text-slate-600">
                      {sale.quantity}x
                    </td>
                    <td className="px-6 py-4 font-mono text-slate-600">
                      {sale.soldPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </td>
                    <td className="px-6 py-4 font-mono font-bold text-emerald-600">
                      {(sale.soldPrice * sale.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </td>
                    <td className="px-6 py-4 text-slate-600">
                      <div>
                        <p className="font-semibold">{sale.clientName}</p>
                        {sale.clientPhone && sale.clientPhone !== 'N/A' && (
                          <p className="text-xs text-slate-400 font-mono">{sale.clientPhone}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => onOpenReceipt(sale)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-sm transition-all duration-150"
                          title="Ver Cupom Simplificado"
                          id={`btn-view-receipt-${sale.id}`}
                        >
                          <FileText className="w-3.5 h-3.5" />
                          Ver Cupom
                        </button>
                        <button
                          onClick={() => setSaleToDelete(sale)}
                          className="inline-flex items-center justify-center p-2 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl transition duration-150 cursor-pointer"
                          title="Excluir Venda"
                          id={`btn-delete-sale-${sale.id}`}
                        >
                          <Trash className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cupom Fiscal Visual Modal with seamless print mechanism */}
      {selectedReceiptSale && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in no-print" id="receipt-modal">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col border border-slate-100 max-h-[90vh]">
            
            {/* Header of Modal */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest font-mono">Cupom de Compra</span>
              <button
                onClick={onCloseReceipt}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Receipt Visual layout (this will look exactly like a thermal paper checkout sheet) */}
            <div className="p-6 overflow-y-auto flex-1 font-mono text-xs text-slate-800 select-text bg-amber-50/10 print-card" id="thermal-receipt-container">
              <div className="text-center space-y-1 pb-4 border-b border-dashed border-slate-200">
                <h3 className="font-bold text-base uppercase tracking-tight text-slate-900">{shopSettings.shopName}</h3>
                {shopSettings.address && <p className="text-[10px] text-slate-500 leading-normal">{shopSettings.address}</p>}
                <p className="text-[10px] text-slate-500">TEL: {shopSettings.shopPhone}</p>
                {shopSettings.cnpj && <p className="text-[10px] text-slate-400">CNPJ: {shopSettings.cnpj}</p>}
              </div>

              <div className="py-3 border-b border-dashed border-slate-200 space-y-1 text-[11px]">
                <p><strong>CUPOM ID:</strong> #{selectedReceiptSale.id}</p>
                <p><strong>DATA:</strong> {formatDate(selectedReceiptSale.timestamp)}</p>
                <p><strong>OPERADOR:</strong> Central ST Imports</p>
              </div>

              {/* Client Detail */}
              <div className="py-3 border-b border-dashed border-slate-200 space-y-1 text-[11px]">
                <p className="font-mono text-[10px] uppercase tracking-wider text-slate-400 font-bold">Cliente</p>
                <p><strong>NOME:</strong> {selectedReceiptSale.clientName}</p>
                <p><strong>TELEFONE:</strong> {selectedReceiptSale.clientPhone || 'N/A'}</p>
              </div>

              {/* Items listing */}
              <div className="py-4 space-y-2 text-[11px] border-b border-dashed border-slate-200">
                <div className="flex justify-between font-bold text-slate-400 uppercase">
                  <span>Produto / Unit</span>
                  <span>Total</span>
                </div>
                <div className="flex justify-between text-slate-800 font-semibold">
                  <span className="max-w-[180px] break-words">
                    {selectedReceiptSale.productName} <br />
                    <span className="text-slate-400 font-normal">{selectedReceiptSale.quantity}x @ {selectedReceiptSale.soldPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                  </span>
                  <span>
                    {(selectedReceiptSale.soldPrice * selectedReceiptSale.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
              </div>

              {/* Totals */}
              <div className="py-3 space-y-1 text-[11px]">
                <div className="flex justify-between font-bold text-sm">
                  <span>VALOR TOTAL VALOR:</span>
                  <span className="text-slate-900 font-bold text-sm">
                    {(selectedReceiptSale.soldPrice * selectedReceiptSale.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
                <p className="text-[9px] text-slate-400 text-center pt-3 italic">
                  *** ESTE É UM COMPROVANTE NÃO-FISCAL ***
                </p>
              </div>
            </div>

            {/* Interactive actions with thermal print alignment */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 grid grid-cols-2 gap-2">
              <button
                onClick={handleDirectPrint}
                className="flex items-center justify-center gap-1.5 p-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 cursor-pointer shadow-xs transition"
                title="Imprimir Cupom 80mm"
              >
                <Printer className="w-4 h-4" />
                Imprimir (80mm)
              </button>

              <a
                href={getWhatsAppShareUrl(selectedReceiptSale)}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-1.5 p-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 cursor-pointer shadow-xs transition"
                title="Enviar por WhatsApp"
              >
                <Share2 className="w-4 h-4" />
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Styled Printable-Only container for browser printing support */}
      {selectedReceiptSale && (
        <>
          <style dangerouslySetInnerHTML={{ __html: `
            @media print {
              html, body {
                margin: 0 !important;
                padding: 0 !important;
                background: #fff !important;
              }
              body * {
                visibility: hidden !important;
              }
              #thermal-print-area, #thermal-print-area * {
                visibility: visible !important;
              }
              #thermal-print-area {
                position: absolute !important;
                left: 0 !important;
                top: 0 !important;
                width: 80mm !important;
                max-width: 80mm !important;
                margin: 0 !important;
                padding: 4mm 6mm !important;
                font-family: 'Courier New', Courier, monospace !important;
                font-size: 12px !important;
                line-height: 1.4 !important;
                color: #000 !important;
                background: #fff !important;
              }
            }
          `}} />

          <div id="thermal-print-area" className="hidden font-mono text-[12px] text-black w-[80mm] leading-normal p-[4mm] bg-white whitespace-pre-wrap">
----------------------------------------
<div className="text-center font-bold uppercase" style={{ textAlign: 'center' }}>{shopSettings.shopName}</div>
<div className="text-center text-[10px]" style={{ textAlign: 'center' }}>{shopSettings.address}</div>
<div className="text-center text-[10px]" style={{ textAlign: 'center' }}>TEL: {shopSettings.shopPhone}</div>
<div className="text-center text-[10px]" style={{ textAlign: 'center' }}>CNPJ: {shopSettings.cnpj || '12.345.678/0001-90'}</div>
----------------------------------------
<div className="font-bold text-center" style={{ textAlign: 'center' }}>RECIBO DE VENDA</div>
Data: {new Date(selectedReceiptSale.timestamp).toLocaleDateString('pt-BR')}   Hora: {new Date(selectedReceiptSale.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}

Cliente: {selectedReceiptSale.clientName}
Telefone: {selectedReceiptSale.clientPhone || 'N/A'}
----------------------------------------
PRODUTO              QTD    VALOR
{selectedReceiptSale.productName.padEnd(20, ' ').substring(0, 20)} {selectedReceiptSale.quantity.toString().padEnd(6, ' ')} {selectedReceiptSale.soldPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
----------------------------------------
TOTAL:                       {(selectedReceiptSale.soldPrice * selectedReceiptSale.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
----------------------------------------
Obrigado pela preferência!
<div className="text-center font-bold uppercase mt-2" style={{ textAlign: 'center' }}>{shopSettings.shopName}</div>
----------------------------------------
          </div>
        </>
      )}

      {/* Sale Delete Custom Confirmation Modal */}
      {saleToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" id="confirm-delete-sale-modal">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 w-full max-w-md overflow-hidden flex flex-col">
            <div className="p-6 text-center space-y-4">
              <div className="mx-auto w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
                <Trash className="w-6 h-6 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-bold text-slate-900">Confirmar Estorno / Cancelamento</h4>
                <p className="text-sm text-slate-500">
                  Tem certeza que deseja estornar a venda do produto <strong className="text-slate-800">"{saleToDelete.productName}"</strong> para o cliente <strong className="text-slate-800">"{saleToDelete.clientName}"</strong>?
                </p>
                <div className="text-xs text-rose-600 bg-rose-50 border border-rose-100 rounded-xl p-3 mt-2 text-left space-y-1">
                  <p className="font-bold">⚠️ Atenção:</p>
                  <p>O valor de {saleToDelete.quantity}x unidades será devolvido automaticamente para o estoque do produto.</p>
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setSaleToDelete(null)}
                className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-xs font-semibold text-slate-750 hover:bg-slate-50 transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteSale(saleToDelete.id);
                  setSaleToDelete(null);
                }}
                className="bg-rose-600 hover:bg-rose-700 text-white px-5 py-2 rounded-xl text-xs font-bold shadow-sm transition-all cursor-pointer"
              >
                Confirmar Estorno
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
