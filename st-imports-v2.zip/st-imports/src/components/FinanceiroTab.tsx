import React, { useState } from 'react';
import { Expense } from '../types';
import { Plus, Trash, DollarSign, Receipt, Filter } from 'lucide-react';

interface FinanceiroTabProps {
  expenses: Expense[];
  onAddExpense: (expense: Omit<Expense, 'id' | 'timestamp'>) => void;
  onDeleteExpense: (id: string) => void;
}

export default function FinanceiroTab({ expenses, onAddExpense, onDeleteExpense }: FinanceiroTabProps) {
  const [description, setDescription] = useState('');
  const [value, setValue] = useState<number>(0);
  const [category, setCategory] = useState('Contas de Consumo (Luz, Net, Água)');
  const [filterCategory, setFilterCategory] = useState('Todas');

  const categories = [
    'Contas de Consumo (Luz, Net, Água)',
    'Fornecedores / Mercadorias',
    'Embalagens',
    'Impostos e Taxas',
    'Marketing e Divulgação',
    'Aluguel / Infraestrutura',
    'Diversos / Outros'
  ];

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || value <= 0) return;

    onAddExpense({
      description: description.trim(),
      value: Number(value),
      category
    });

    setDescription('');
    setValue(0);
    setCategory('Contas de Consumo (Luz, Net, Água)');
  };

  const filteredExpenses = filterCategory === 'Todas'
    ? expenses
    : expenses.filter(e => e.category === filterCategory);

  const totalFilteredValue = filteredExpenses.reduce((acc, e) => acc + e.value, 0);

  return (
    <div className="space-y-6" id="financeiro-tab">
      
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-800">Financeiro & Despesas</h2>
        <p className="text-sm text-slate-500">Cadastre todos os custos operacionais da loja para calcular de forma real a divisão de lucros líquidos.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="financeiro-layout-grid">
        
        {/* Form Panel to add new expenses */}
        <div className="bg-white rounded-3xl p-6 border border-[#E5E9EB]/65 shadow-[0_8px_30px_rgb(0,0,0,0.015)] self-start h-auto">
          <h3 className="font-bold text-slate-800 text-base mb-4 flex items-center gap-2">
            <Receipt className="w-4.5 h-4.5 text-rose-500" />
            Lançar Despesa / Saída
          </h3>

          <form onSubmit={handleAddExpense} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Descrição da Despesa *</label>
              <input
                type="text"
                required
                placeholder="Ex: Conta de Luz / Recarga Embalagens"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Valor Pago *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 font-bold text-xs">R$</span>
                  <input
                    type="number"
                    required
                    min="0.01"
                    step="0.01"
                    value={value === 0 ? '' : value}
                    onChange={(e) => setValue(Math.max(0, parseFloat(e.target.value) || 0))}
                    placeholder="0,00"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Categoria *</label>
                <select
                  required
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all cursor-pointer"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl py-2.5 text-sm transition cursor-pointer shadow-sm flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4.5 h-4.5" />
              Lançar Despesa
            </button>
          </form>
        </div>

        {/* Expenses List Panel */}
        <div className="bg-white rounded-3xl p-6 border border-[#E5E9EB]/65 shadow-[0_8px_30px_rgb(0,0,0,0.015)] lg:col-span-2 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-50">
            <h3 className="font-bold text-slate-800 text-base">Registros de Saídas</h3>
            
            {/* Filter by Category */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400 font-semibold flex items-center gap-1">
                <Filter className="w-3.5 h-3.5" /> Filtrar:
              </span>
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-700 cursor-pointer text-xs"
              >
                <option value="Todas">Todas as Categorias</option>
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Table representation */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-500 border-b border-slate-100 text-[10px] font-bold uppercase tracking-wider">
                  <th className="px-4 py-3">Lançamento</th>
                  <th className="px-4 py-3">Nome / Detalhe</th>
                  <th className="px-4 py-3">Grupo / Categoria</th>
                  <th className="px-4 py-3">Total Pago</th>
                  <th className="px-4 py-3 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-sm">
                {filteredExpenses.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-12 text-center text-slate-400">
                      Nenhuma despesa ou custo registrado neste filtro.
                    </td>
                  </tr>
                ) : (
                  filteredExpenses.slice().reverse().map(expense => (
                    <tr key={expense.id} className="hover:bg-slate-50/50 transition">
                      <td className="px-4 py-3 text-xs text-slate-400 font-mono">
                        {new Date(expense.timestamp).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-700">
                        {expense.description}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-500">
                        {expense.category}
                      </td>
                      <td className="px-4 py-3 font-bold text-rose-500 font-mono">
                        {expense.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </td>
                      <td className="px-4 py-4 text-center">
                        <button
                          onClick={() => {
                            if (window.confirm(`Gostaria de excluir a despesa "${expense.description}"?`)) {
                              onDeleteExpense(expense.id);
                            }
                          }}
                          className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1.5 rounded-lg transition cursor-pointer"
                          title="Remover Despesa"
                        >
                          <Trash className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Sum box */}
          <div className="pt-4 border-t border-slate-100 flex justify-between items-center bg-slate-50/50 p-4 rounded-xl font-mono text-sm">
            <span className="font-sans font-bold text-slate-500">Soma Total das Saídas Listadas:</span>
            <span className="text-xl font-extrabold text-rose-600">
              {totalFilteredValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </span>
          </div>

        </div>

      </div>
    </div>
  );
}
