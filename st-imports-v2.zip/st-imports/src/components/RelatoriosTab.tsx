import React, { useState } from 'react';
import { Product, Sale, Expense } from '../types';
import { Download, FileDown, Layers, Calendar, Printer } from 'lucide-react';

interface RelatoriosTabProps {
  products: Product[];
  sales: Sale[];
  expenses: Expense[];
}

export default function RelatoriosTab({ products, sales, expenses }: RelatoriosTabProps) {
  // Available months list derived from both sales and expenses
  const dates = [...sales.map(s => s.timestamp), ...expenses.map(e => e.timestamp)];
  const availableMonths = Array.from(new Set(
    dates.map(dateStr => dateStr.substring(0, 7))
  )).sort().reverse();

  // Selected month defaulting to latest/current or first available
  const currentMonthStr = new Date().toISOString().substring(0, 7);
  const [selectedMonth, setSelectedMonth] = useState(
    availableMonths.includes(currentMonthStr) ? currentMonthStr : (availableMonths[0] || currentMonthStr)
  );

  // Filter lists based on selection
  const monthlySales = sales.filter(s => s.timestamp.startsWith(selectedMonth));
  const monthlyExpenses = expenses.filter(e => e.timestamp.startsWith(selectedMonth));

  // Calculating monthly values
  const totalSalesRevenue = monthlySales.reduce((acc, s) => acc + (s.soldPrice * s.quantity), 0);
  
  const totalSalesCOGS = monthlySales.reduce((acc, s) => {
    const product = products.find(p => p.id === s.productId);
    const cost = product ? product.costPrice : (s.soldPrice * 0.5);
    return acc + (cost * s.quantity);
  }, 0);

  const totalExpenses = monthlyExpenses.reduce((acc, e) => acc + e.value, 0);

  // Net Profit
  const netProfit = totalSalesRevenue - totalSalesCOGS - totalExpenses;

  // Format YYYY-MM into beautiful label (Ex: Junho de 2026)
  const formatMonthLabel = (yearMonth: string) => {
    if (!yearMonth) return '';
    const [year, month] = yearMonth.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, 1);
    return date.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  };

  // EXPORT TO EXCEL: Generate custom brazilian Excel compatible CSV (semi-colon separated, UTF-8 BOM)
  const exportToCSV = () => {
    let csvContent = "\uFEFF"; // UTF-8 BOM to ensure symbols/letters show up correctly in Excel (pt-BR locale)
    
    // Header
    csvContent += "Relatório Comercial da Loja - " + formatMonthLabel(selectedMonth) + "\n\n";
    
    // Summary table
    csvContent += "Indicador Métrica;Valor (R$)\n";
    csvContent += `Faturamento Total de Vendas;${totalSalesRevenue.toFixed(2).replace('.', ',')}\n`;
    csvContent += `Custo das Mercadorias Vendidas (CMV);${totalSalesCOGS.toFixed(2).replace('.', ',')}\n`;
    csvContent += `Lucro Bruto do Varejo;${(totalSalesRevenue - totalSalesCOGS).toFixed(2).replace('.', ',')}\n`;
    csvContent += `Despesas e Custos Operacionais;${totalExpenses.toFixed(2).replace('.', ',')}\n`;
    csvContent += `Lucro Líquido Real;${netProfit.toFixed(2).replace('.', ',')}\n\n`;

    // Sales table
    csvContent += "DETALHAMENTO DE VENDAS\n";
    csvContent += "Data;Produto Vendido;Quantidade;Preço Unitário (R$);Total Venda (R$);Cliente;Telefone\n";
    
    monthlySales.forEach(s => {
      const date = new Date(s.timestamp).toLocaleDateString('pt-BR');
      csvContent += `${date};${s.productName};${s.quantity};${s.soldPrice.toFixed(2).replace('.', ',')};${(s.soldPrice * s.quantity).toFixed(2).replace('.', ',')};${s.clientName};${s.clientPhone}\n`;
    });

    csvContent += "\n";

    // Expenses table
    csvContent += "DETALHAMENTO DE DESPESAS\n";
    csvContent += "Data;Descrição;Categoria;Valor Pago (R$)\n";
    
    monthlyExpenses.forEach(e => {
      const date = new Date(e.timestamp).toLocaleDateString('pt-BR');
      csvContent += `${date};${e.description};${e.category};${e.value.toFixed(2).replace('.', ',')}\n`;
    });

    // Create file trigger download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Relatorio_Mensal_${selectedMonth}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const printReport = () => {
    window.print();
  };

  return (
    <div className="space-y-6" id="relatorios-tab">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800">Relatórios de Desempenho</h2>
          <p className="text-sm text-slate-500">Agregue lucros e perdas por mês e exporte em Excel ou salve como relatório em PDF.</p>
        </div>

        {/* Month Selector Dropdown */}
        <div className="flex items-center gap-2 self-start sm:self-center" id="month-selector-group">
          <Calendar className="w-5 h-5 text-slate-400" />
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm text-slate-800 font-bold focus:outline-none focus:ring-2 focus:ring-indigo-600 cursor-pointer shadow-sm"
          >
            {availableMonths.length === 0 ? (
              <option value={currentMonthStr}>{formatMonthLabel(currentMonthStr)}</option>
            ) : (
              availableMonths.map(month => (
                <option key={month} value={month}>{formatMonthLabel(month)}</option>
              ))
            )}
          </select>
        </div>
      </div>

      {/* Quick Action Export triggers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Excel Export Button */}
        <button
          onClick={exportToCSV}
          className="flex items-center justify-center gap-3 bg-white hover:bg-slate-50/55 border border-[#E5E9EB] text-slate-800 font-bold rounded-3xl p-6 transition-all duration-300 shadow-[0_8px_30px_rgb(0,0,0,0.01)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.02)] group cursor-pointer text-left"
          id="btn-export-excel"
        >
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl group-hover:scale-105 transition-transform">
            <FileDown className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-extrabold text-slate-800">Exportar para Excel (.CSV)</h4>
            <p className="text-xs text-slate-400 mt-0.5">Planilha pronta com faturamento, custos e demonstrativo de lucros.</p>
          </div>
        </button>

        {/* PDF Export Button */}
        <button
          onClick={printReport}
          className="flex items-center justify-center gap-3 bg-white hover:bg-slate-50/55 border border-[#E5E9EB] text-slate-800 font-bold rounded-3xl p-6 transition-all duration-300 shadow-[0_8px_30px_rgb(0,0,0,0.01)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.02)] group cursor-pointer text-left"
          id="btn-export-pdf"
        >
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl group-hover:scale-105 transition-transform">
            <Printer className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-extrabold text-slate-800">Visualizar e Salvar em PDF</h4>
            <p className="text-xs text-slate-400 mt-0.5">Gera um relatório profissional pré-formatado ideal para imprimir ou guardar.</p>
          </div>
        </button>

      </div>

      {/* Visual Report Details on screen */}
      <div className="bg-white border border-[#E5E9EB]/65 rounded-3xl p-6 shadow-sm space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
            <Layers className="w-4.5 h-4.5 text-indigo-600" />
            Demonstrativo Gráfico e Numérico ({formatMonthLabel(selectedMonth)})
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Valores acumulados para este período de competência.</p>
        </div>

        {/* Visual progress comparison */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 font-mono text-sm border-t border-slate-50 pt-5">
          <div className="space-y-1 bg-slate-50 p-4 rounded-xl border border-slate-100">
            <span className="text-xs font-semibold font-sans text-slate-400 block mb-1">Entradas de Caixa</span>
            <p className="text-xl font-bold text-emerald-600">
              {totalSalesRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </p>
            <p className="text-[10px] text-slate-400 font-sans mt-0.5">{monthlySales.length} vendas concretizadas</p>
          </div>

          <div className="space-y-1 bg-slate-50 p-4 rounded-xl border border-slate-100">
            <span className="text-xs font-semibold font-sans text-slate-400 block mb-1">Custo das Vendas (CMV)</span>
            <p className="text-xl font-bold text-rose-500">
              {totalSalesCOGS.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </p>
            <p className="text-[10px] text-slate-400 font-sans mt-0.5">Dinheiro que cobriu custo do estoque</p>
          </div>

          <div className="space-y-1 bg-slate-50 p-4 rounded-xl border border-slate-100">
            <span className="text-xs font-semibold font-sans text-slate-400 block mb-1">Despesas Operacionais adicionais</span>
            <p className="text-xl font-bold text-rose-600">
              {totalExpenses.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </p>
            <p className="text-[10px] text-slate-400 font-sans mt-0.5">{monthlyExpenses.length} saídas adicionais pagas</p>
          </div>
        </div>

        {/* Big Profit Indicator */}
        <div className="p-6 bg-slate-900 text-white rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-6 font-sans">
          <div className="space-y-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Resultado Financeiro Final</span>
            <h4 className={`text-3xl font-extrabold font-sans ${netProfit >= 0 ? 'text-indigo-400' : 'text-rose-550 text-rose-500'}`}>
              {netProfit.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </h4>
            <p className="text-xs text-slate-400 mt-1">Margem de Lucratividade Real sobre Vendas: {totalSalesRevenue > 0 ? ((netProfit / totalSalesRevenue) * 100).toFixed(1) + '%' : '0%'}</p>
          </div>
          
          <div className="bg-slate-850 p-4 rounded-2xl text-xs space-y-1.5 font-mono max-w-xs w-full text-slate-300 border border-slate-800/80">
            <div className="flex justify-between">
              <span>Faturamento (+)</span>
              <span>R$ {totalSalesRevenue.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Sua Mercadoria (-)</span>
              <span>R$ {totalSalesCOGS.toFixed(2)}</span>
            </div>
            <div className="flex justify-between border-b border-slate-700/80 pb-2">
              <span>Contas & Despesas (-)</span>
              <span>R$ {totalExpenses.toFixed(2)}</span>
            </div>
            <div className="flex justify-between pt-1 font-bold text-white text-sm">
              <span>Lucro Real</span>
              <span className={netProfit >= 0 ? 'text-indigo-400' : 'text-rose-400'}>R$ {netProfit.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Styled offscreen print sheet for Monthly Report representation */}
      <div className="hidden print-only fixed inset-0 font-sans p-16 text-slate-900 bg-white" id="main-report-printout">
        <div className="text-center space-y-2 pb-6 border-b-2 border-black mb-6">
          <h1 className="text-2xl font-bold uppercase">Relatório de Gestão Comercial Mensal</h1>
          <p className="text-base font-semibold">Período de Referência: {formatMonthLabel(selectedMonth)}</p>
          <p className="text-xs font-mono">Gerado em: {new Date().toLocaleDateString('pt-BR')}</p>
        </div>

        <h3 className="text-lg font-bold border-b border-black mb-3 pb-1">1. DEMONSTRATIVO DE RESULTADOS</h3>
        <table className="w-full text-left font-mono text-sm mb-8 border-collapse">
          <thead>
            <tr className="border-b border-black font-sans uppercase text-xs">
              <th className="py-2">Métrica Comercial</th>
              <th className="py-2 text-right">Valor em Reais (R$)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-300">
            <tr>
              <td className="py-2 font-bold text-slate-850">Faturamento Bruto das Vendas (+)</td>
              <td className="py-2 text-right font-bold">R$ {totalSalesRevenue.toFixed(2)}</td>
            </tr>
            <tr>
              <td className="py-2">Custo das Mercadorias Vendidas (CMV) (-)</td>
              <td className="py-2 text-right">R$ {totalSalesCOGS.toFixed(2)}</td>
            </tr>
            <tr>
              <td className="py-2 font-bold text-slate-700">Lucro Bruto do Varejo</td>
              <td className="py-2 text-right">R$ {(totalSalesRevenue - totalSalesCOGS).toFixed(2)}</td>
            </tr>
            <tr>
              <td className="py-2">Custos Operacionais e Saídas Financeiras (-)</td>
              <td className="py-2 text-right">R$ {totalExpenses.toFixed(2)}</td>
            </tr>
            <tr className="border-t border-black font-bold text-base">
              <td className="py-3 font-bold uppercase text-slate-900">Resultado Líquido do Exercício</td>
              <td className="py-3 text-right text-slate-950 font-extrabold pb-4">R$ {netProfit.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>

        {/* Division split inside printout */}
        <h3 className="text-lg font-bold border-b border-black mb-3 pb-1">2. DIVISÃO ENTRE SÓCIOS</h3>
        <ul className="list-disc pl-5 text-sm space-y-1 mb-8">
          <li><strong>Pedro:</strong> {totalExpenses + totalSalesCOGS > 0 ? (netProfit > 0 ? `R$ ${(netProfit * 0.5).toFixed(2)}` : 'R$ 0,00') : 'R$ 0,00'} (Cota de 50% dividida)</li>
          <li><strong>Thalisson:</strong> {totalExpenses + totalSalesCOGS > 0 ? (netProfit > 0 ? `R$ ${(netProfit * 0.5).toFixed(2)}` : 'R$ 0,00') : 'R$ 0,00'} (Cota de 50% dividida)</li>
        </ul>

        {/* Breakdown of sales */}
        <h3 className="text-lg font-bold border-b border-black mb-3 pb-1">3. HISTÓRICO DE PEDIDOS ({monthlySales.length} ITENS)</h3>
        <table className="w-full text-xs font-mono mb-8 border-collapse">
          <thead>
            <tr className="border-b border-black text-left">
              <th className="py-1">Data</th>
              <th className="py-1">Produto</th>
              <th className="py-1">Qtd</th>
              <th className="py-1">Preço Un.</th>
              <th className="py-1 text-right">Total Pago</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {monthlySales.map(s => (
              <tr key={s.id}>
                <td className="py-1">{new Date(s.timestamp).toLocaleDateString('pt-BR')}</td>
                <td className="py-1 font-sans">{s.productName}</td>
                <td className="py-1">{s.quantity}x</td>
                <td className="py-1">R$ {s.soldPrice.toFixed(2)}</td>
                <td className="py-1 text-right">R$ {(s.soldPrice * s.quantity).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-12 text-center text-[10px] text-slate-400">
          *** Relatório gerado eletronicamente e destinado de forma exclusiva para fins de controladoria societária interna ***
        </div>
      </div>

    </div>
  );
}
