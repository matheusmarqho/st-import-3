import React from 'react';
import { Product, Sale, Expense, PartnerSplit } from '../types';
import { Users, DollarSign, ArrowRightLeft, ShieldAlert } from 'lucide-react';

interface SociosTabProps {
  products: Product[];
  sales: Sale[];
  expenses: Expense[];
  partnerSplit: PartnerSplit;
  onUpdatePartnerSplit: (split: PartnerSplit) => void;
}

export default function SociosTab({ products, sales, expenses, partnerSplit, onUpdatePartnerSplit }: SociosTabProps) {
  // Current month of business (Format: YYYY-MM)
  const currentMonthStr = new Date().toISOString().substring(0, 7);

  // Filter current month logs
  const currentMonthSales = sales.filter(s => s.timestamp.startsWith(currentMonthStr));
  const currentMonthExpenses = expenses.filter(e => e.timestamp.startsWith(currentMonthStr));

  // Revenue for current month
  const currentMonthRevenue = currentMonthSales.reduce((acc, s) => acc + (s.soldPrice * s.quantity), 0);

  // Cost of goods sold (CMV)
  const currentMonthCOGS = currentMonthSales.reduce((acc, s) => {
    const product = products.find(p => p.id === s.productId);
    const cost = product ? product.costPrice : (s.soldPrice * 0.5);
    return acc + (cost * s.quantity);
  }, 0);

  // Total expenses
  const totalExpensesValue = currentMonthExpenses.reduce((acc, e) => acc + e.value, 0);

  // Current Net Profit: Revenue - CMV - Expenses
  const currentMonthNetProfit = currentMonthRevenue - currentMonthCOGS - totalExpensesValue;

  // Split calculation
  const pedroShare = Math.max(0, currentMonthNetProfit * (partnerSplit.pedroPercent / 100));
  const thalissonShare = Math.max(0, currentMonthNetProfit * (partnerSplit.thalissonPercent / 100));

  // Handle slide adjustment for Pedro's percentage
  const handlePedroSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const pedroVal = Math.min(100, Math.max(0, parseInt(e.target.value) || 0));
    onUpdatePartnerSplit({
      pedroPercent: pedroVal,
      thalissonPercent: 100 - pedroVal
    });
  };

  // Handle slide adjustment for Thalisson's percentage
  const handleThalissonSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const thalissonVal = Math.min(100, Math.max(0, parseInt(e.target.value) || 0));
    onUpdatePartnerSplit({
      pedroPercent: 100 - thalissonVal,
      thalissonPercent: thalissonVal
    });
  };

  return (
    <div className="space-y-6" id="socios-tab">
      
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-800">Sócios & Divisão de Lucro</h2>
        <p className="text-sm text-slate-500">Cadastre e distribua os lucros reais de forma proporcional aos percentuais acordados.</p>
      </div>

      {/* Main Calculation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="socios-layout-grid">
        
        {/* Core summary card */}
        <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-sm flex flex-col justify-between min-h-[220px]">
          <div>
            <div className="bg-slate-800 p-2 text-indigo-400 rounded-lg w-10 h-10 flex items-center justify-center mb-4">
              <DollarSign className="w-6 h-6" />
            </div>
            <span className="text-xs uppercase font-medium text-slate-450 font-mono tracking-wider">Lucro Líquido Real do Mês</span>
            <h3 className={`text-3xl font-extrabold tracking-tight mt-1 ${currentMonthNetProfit >= 0 ? 'text-indigo-400' : 'text-rose-400'}`}>
              {currentMonthNetProfit.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </h3>
          </div>
          
          <div className="border-t border-slate-850 pt-4 mt-6 text-xs text-slate-400 space-y-2 font-mono">
            <div className="flex justify-between">
              <span>Faturamento Total (+):</span>
              <span className="text-emerald-400">+{currentMonthRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
            </div>
            <div className="flex justify-between">
              <span>Custo das Vendas (CMV) (-):</span>
              <span className="text-rose-400">-{currentMonthCOGS.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
            </div>
            <div className="flex justify-between">
              <span>Outras Despesas (-):</span>
              <span className="text-rose-400">-{totalExpensesValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
            </div>
          </div>
        </div>

        {/* Real-time slider and adjustments */}
        <div className="bg-white rounded-3xl p-6 border border-[#E5E9EB]/65 shadow-[0_8px_30px_rgb(0,0,0,0.015)] lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-800 text-base flex items-center gap-2">
              <Users className="w-5 h-5 text-slate-700" />
              Acordo de Participação societária
            </h3>
            <span className="text-xs font-semibold px-2.5 py-1 bg-indigo-50 text-indigo-800 rounded-full font-mono flex items-center gap-1">
              <ArrowRightLeft className="w-3.5 h-3.5" /> Soma 100%
            </span>
          </div>

          <div className="space-y-6">
            {/* Pedro Slider */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="font-bold text-slate-700">🧑‍💼 Pedro (Sócio)</span>
                <span className="font-mono bg-slate-50 border border-slate-100 text-slate-750 font-bold px-2.5 py-1 rounded-lg text-xs">
                  {partnerSplit.pedroPercent}% de participação
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={partnerSplit.pedroPercent}
                onChange={handlePedroSliderChange}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-xs text-slate-400 font-mono">
                <span>0%</span>
                <span>Recebe: {pedroShare.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                <span>100%</span>
              </div>
            </div>

            {/* Thalisson Slider */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="font-bold text-slate-700">🧑‍💼 Thalisson (Sócio)</span>
                <span className="font-mono bg-slate-50 border border-slate-100 text-slate-755 font-bold px-2.5 py-1 rounded-lg text-xs">
                  {partnerSplit.thalissonPercent}% de participação
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={partnerSplit.thalissonPercent}
                onChange={handleThalissonSliderChange}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-xs text-slate-400 font-mono">
                <span>0%</span>
                <span>Recebe: {thalissonShare.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                <span>100%</span>
              </div>
            </div>
          </div>

          {currentMonthNetProfit < 0 && (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-start gap-2 leading-relaxed">
              <ShieldAlert className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <strong>Atenção:</strong> A loja possui lucro líquido negativo neste mês corrente. Na prática societária, isso representa um saldo deficitário e os sócios devem decidir se reinvestem na operação de forma proporcional a essa mesma participação.
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Summary division review */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white/55 border border-[#E5E9EB]/65 p-6 rounded-3xl">
        
        {/* Pedro card outcome */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 flex flex-col justify-between shadow-[0_8px_30px_rgb(0,0,0,0.01)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.02)] transition-all">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Retirada Estimada Pedro</p>
            <h4 className="text-2xl font-extrabold text-slate-800 mt-1">
              {pedroShare.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </h4>
          </div>
          <p className="text-xs text-slate-420 leading-relaxed mt-4">
            Em conformidade com a cota acordada de <strong>{partnerSplit.pedroPercent}%</strong> sobre o saldo mensal real de {currentMonthNetProfit.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}.
          </p>
        </div>

        {/* Thalisson card outcome */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 flex flex-col justify-between shadow-[0_8px_30px_rgb(0,0,0,0.01)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.02)] transition-all">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Retirada Estimada Thalisson</p>
            <h4 className="text-2xl font-extrabold text-slate-800 mt-1">
              {thalissonShare.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </h4>
          </div>
          <p className="text-xs text-slate-420 leading-relaxed mt-4">
            Em conformidade com a cota acordada de <strong>{partnerSplit.thalissonPercent}%</strong> sobre o saldo mensal real de {currentMonthNetProfit.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}.
          </p>
        </div>

      </div>

    </div>
  );
}
