import React from 'react';
import { Product, Sale, Expense } from '../types';
import { TrendingUp, Package, DollarSign, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface DashboardTabProps {
  products: Product[];
  sales: Sale[];
  expenses: Expense[];
}

export default function DashboardTab({ products, sales, expenses }: DashboardTabProps) {
  // Current month and year (Format: YYYY-MM)
  const currentMonthStr = new Date().toISOString().substring(0, 7);

  // 1. Total Stock Value (Soma do custo de todos os produtos em estoque)
  const totalStockValue = products.reduce((acc, p) => acc + (p.costPrice * p.quantity), 0);

  // 2. Filter sales and expenses for the current month
  const currentMonthSales = sales.filter(s => s.timestamp.startsWith(currentMonthStr));
  const currentMonthExpenses = expenses.filter(e => e.timestamp.startsWith(currentMonthStr));

  // Revenue for current month
  const currentMonthRevenue = currentMonthSales.reduce((acc, s) => acc + (s.soldPrice * s.quantity), 0);

  // Cost of goods sold (CMV)
  const currentMonthCOGS = currentMonthSales.reduce((acc, s) => {
    const product = products.find(p => p.id === s.productId);
    // fallback option if product was deleted: use a default calculated from sold price or cost database
    const cost = product ? product.costPrice : (s.soldPrice * 0.5);
    return acc + (cost * s.quantity);
  }, 0);

  // Total expenses for current month
  const totalExpensesValue = currentMonthExpenses.reduce((acc, e) => acc + e.value, 0);

  // Net Profit: Faturamento - CMV - Despesas
  const currentMonthNetProfit = currentMonthRevenue - currentMonthCOGS - totalExpensesValue;

  return (
    <div className="space-y-6" id="dashboard-tab">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800">Painel Inicial</h2>
          <p className="text-sm text-slate-500">Resumo geral do seu negócio para o mês de {new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}.</p>
        </div>
        <div className="text-xs bg-slate-100 text-slate-600 rounded-lg px-3 py-1.5 font-mono self-start md:self-center">
          Atualizado em: {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Total Stock Cost Card */}
        <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.02)] border border-slate-100/80 p-6 flex items-start justify-between min-h-[140px]" id="stat-stock-cost">
          <div className="space-y-2">
            <span className="text-sm font-medium text-slate-500">Valor do Estoque (Custo)</span>
            <div className="text-2xl font-bold text-slate-800 tracking-tight">
              {totalStockValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </div>
            <p className="text-xs text-slate-400">Soma do custo de aquisição {products.reduce((acc, p) => acc + p.quantity, 0)} itens</p>
          </div>
          <div className="bg-amber-50 p-3 rounded-2xl text-amber-600">
            <Package className="w-6 h-6" />
          </div>
        </div>

        {/* Total Sales Value Card */}
        <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.02)] border border-slate-100/80 p-6 flex items-start justify-between min-h-[140px]" id="stat-sales-revenue">
          <div className="space-y-2">
            <span className="text-sm font-medium text-slate-500">Faturamento Mensal</span>
            <div className="text-2xl font-bold text-slate-850 tracking-tight text-emerald-600">
              {currentMonthRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </div>
            <p className="text-xs text-slate-400">{currentMonthSales.length} transações registradas</p>
          </div>
          <div className="bg-emerald-50 p-3 rounded-2xl text-emerald-600">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        {/* Expenses Card */}
        <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.02)] border border-slate-[#E5E9EB]/60 p-6 flex items-start justify-between min-h-[140px]" id="stat-expenses">
          <div className="space-y-2">
            <span className="text-sm font-medium text-slate-500">Despesas Operacionais</span>
            <div className="text-2xl font-bold text-rose-600 tracking-tight">
              {totalExpensesValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </div>
            <p className="text-xs text-slate-400">{currentMonthExpenses.length} saídas financeiras salvas</p>
          </div>
          <div className="bg-rose-50 p-3 rounded-2xl text-rose-600">
            <ArrowDownRight className="w-6 h-6" />
          </div>
        </div>

        {/* Net Profit Card */}
        <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.02)] border border-slate-100/80 p-6 flex items-start justify-between min-h-[140px]" id="stat-net-profit">
          <div className="space-y-2">
            <span className="text-sm font-medium text-slate-500">Lucro Líquido Real</span>
            <div className={`text-2xl font-bold tracking-tight ${currentMonthNetProfit >= 0 ? 'text-indigo-600' : 'text-rose-600'}`}>
              {currentMonthNetProfit.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </div>
            <p className="text-xs text-slate-400">Faturamento menos custos e CMV</p>
          </div>
          <div className={`p-3 rounded-2xl ${currentMonthNetProfit >= 0 ? 'bg-indigo-50 text-indigo-600' : 'bg-rose-50 text-rose-600'}`}>
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* Sub sections: Quick Stock summary and recent sales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Key Alert: Low Stock */}
        <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.02)] border border-slate-100/80 p-6" id="card-alert-stock">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <h3 className="font-semibold text-slate-800">Alertas de Estoque Baixo</h3>
            <span className="text-xs font-semibold px-2.5 py-1 bg-rose-50 text-rose-700 rounded-full border border-rose-100/60 font-mono animate-pulse">
              {products.filter(p => p.quantity <= 3).length} críticos
            </span>
          </div>
          <div className="mt-4 divide-y divide-slate-50 max-h-[220px] overflow-y-auto w-full">
            {products.filter(p => p.quantity <= 3).length === 0 ? (
              <div className="py-6 text-center text-sm text-emerald-600 font-semibold bg-emerald-50/50 rounded-xl my-4">
                🎉 Nenhum produto com estoque crítico (≤ 3 un)!
              </div>
            ) : (
              products.filter(p => p.quantity <= 3).map(product => (
                <div key={product.id} className="py-3.5 flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3">
                    {product.image ? (
                      <img src={product.image} alt={product.name} className="w-10 h-10 rounded-xl object-cover border border-slate-100" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 font-bold text-xs">
                        {product.name.charAt(0)}
                      </div>
                    )}
                    <div>
                      <p className="font-medium text-slate-800">{product.name}</p>
                      <p className="text-xs text-slate-450">Preço Mín: {product.minSellPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                    </div>
                  </div>
                  <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${product.quantity === 0 ? 'bg-red-50 text-red-750 border border-red-100/70' : 'bg-amber-50 text-amber-750 border border-amber-100/70'}`}>
                    {product.quantity} un em estoque
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent sales summary */}
        <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.02)] border border-slate-100/80 p-6" id="card-recent-sales">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <h3 className="font-semibold text-slate-800">Últimas Vendas</h3>
            <span className="text-xs font-semibold px-2.5 py-1 bg-indigo-50 text-indigo-750 rounded-full border border-indigo-100/60">
              Este mês
            </span>
          </div>
          <div className="mt-4 divide-y divide-slate-50 max-h-[220px] overflow-y-auto">
            {currentMonthSales.length === 0 ? (
              <div className="py-6 text-center text-sm text-slate-400">
                Nenhuma venda realizada este mês.
              </div>
            ) : (
              currentMonthSales.slice(-5).reverse().map(sale => (
                <div key={sale.id} className="py-3.5 flex items-center justify-between text-sm">
                  <div>
                    <p className="font-semibold text-slate-850">{sale.productName}</p>
                    <p className="text-xs text-slate-400">
                      Cliente: {sale.clientName || 'Consumidor'} • {new Date(sale.timestamp).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-emerald-600">
                      {(sale.soldPrice * sale.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </p>
                    <p className="text-xs text-slate-450">{sale.quantity} und.</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
