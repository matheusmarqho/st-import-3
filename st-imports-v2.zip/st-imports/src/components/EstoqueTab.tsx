import React, { useState, useRef } from 'react';
import { Product } from '../types';
import { Plus, Edit, Trash, Search, Image as ImageIcon, Check, X, Camera } from 'lucide-react';

interface EstoqueTabProps {
  products: Product[];
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onEditProduct: (id: string, product: Partial<Product>) => void;
  onDeleteProduct: (id: string) => void;
}

export default function EstoqueTab({ products, onAddProduct, onEditProduct, onDeleteProduct }: EstoqueTabProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [stockFilter, setStockFilter] = useState<'all' | 'critical' | 'available' | 'out_of_stock'>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // For custom confirmation before delete modal
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  // Form states and errors
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState<number>(0);
  const [costPrice, setCostPrice] = useState<number>(0);
  const [minSellPrice, setMinSellPrice] = useState<number>(0);
  const [photoBase64, setPhotoBase64] = useState<string>('');
  const [dragActive, setDragActive] = useState(false);
  const [errors, setErrors] = useState<{
    name?: string;
    quantity?: string;
    costPrice?: string;
    minSellPrice?: string;
  }>({});
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter products by search and available quantity (<= 3 is critical)
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;

    if (stockFilter === 'critical') return p.quantity > 0 && p.quantity <= 3;
    if (stockFilter === 'available') return p.quantity > 0;
    if (stockFilter === 'out_of_stock') return p.quantity === 0;
    return true; // 'all'
  });

  // Process file upload and compress it on-the-fly
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processPhoto(file);
    }
  };

  const processPhoto = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Create canvas to downscale and compress
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 200;
        const MAX_HEIGHT = 200;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL('image/jpeg', 0.7); // 70% quality jpeg keeps it super light! (~10KB)
          setPhotoBase64(compressed);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Drag-drop events
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processPhoto(e.dataTransfer.files[0]);
    }
  };

  // Open modal for adding
  const openAddModal = () => {
    setEditingId(null);
    setName('');
    setQuantity(0);
    setCostPrice(0);
    setMinSellPrice(0);
    setPhotoBase64('');
    setErrors({});
    setIsModalOpen(true);
  };

  // Open modal for editing
  const openEditModal = (p: Product) => {
    setEditingId(p.id);
    setName(p.name);
    setQuantity(p.quantity);
    setCostPrice(p.costPrice);
    setMinSellPrice(p.minSellPrice);
    setPhotoBase64(p.image || '');
    setErrors({});
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: typeof errors = {};

    if (!name.trim()) {
      newErrors.name = "O nome do produto é obrigatório.";
    }
    if (quantity === undefined || quantity < 0) {
      newErrors.quantity = "A quantidade deve ser maior ou igual a 0.";
    }
    if (costPrice === undefined || costPrice <= 0) {
      newErrors.costPrice = "O valor de custo deve ser maior que zero (R$ 0,00).";
    }
    if (minSellPrice === undefined || minSellPrice <= 0) {
      newErrors.minSellPrice = "O preço mínimo de venda deve ser maior que zero (R$ 0,00).";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const data = {
      name: name.trim(),
      quantity: Number(quantity),
      costPrice: Number(costPrice),
      minSellPrice: Number(minSellPrice),
      image: photoBase64 || undefined
    };

    if (editingId) {
      onEditProduct(editingId, data);
    } else {
      onAddProduct(data);
    }

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6" id="estoque-tab">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800">Controle de Estoque</h2>
          <p className="text-sm text-slate-500">Cadastre novos produtos, edite quantidades e valores de custo/venda.</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl px-4.5 py-2.5 font-bold transition text-sm cursor-pointer shadow-sm self-start sm:self-center"
          id="btn-add-product"
        >
          <Plus className="w-4 h-4" />
          Novo Produto
        </button>
      </div>

      {/* Search Bar & Stock Filter Dropdown */}
      <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between" id="search-filter-controls">
        <div className="relative flex-1 max-w-md" id="search-container">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            placeholder="Buscar produto por nome..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-[#E5E9EB] rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all font-semibold"
          />
        </div>

        {/* Filter Dropdown */}
        <div className="flex items-center gap-2" id="stock-filter-container">
          <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">Status Estoque:</span>
          <select
            value={stockFilter}
            onChange={(e) => setStockFilter(e.target.value as any)}
            className="bg-white border border-[#E5E9EB] rounded-xl px-3 py-2.5 text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-600 cursor-pointer shadow-xs min-w-[150px]"
          >
            <option value="all">Ver Todos ({products.length})</option>
            <option value="critical">Crítico (≤ 3 un) ({products.filter(p => p.quantity > 0 && p.quantity <= 3).length})</option>
            <option value="available">Disponível ({products.filter(p => p.quantity > 0).length})</option>
            <option value="out_of_stock">Sem Estoque ({products.filter(p => p.quantity === 0).length})</option>
          </select>
        </div>
      </div>

      {/* Grid of Products */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white border border-dashed border-slate-200 rounded-2xl p-12 text-center" id="empty-products-placeholder">
          <ImageIcon className="w-12 h-12 text-slate-300 mx-auto mb-4 animate-pulse" />
          <p className="text-base font-semibold text-slate-800">Nenhum produto cadastrado</p>
          <p className="text-xs text-slate-400 mt-1">Insira produtos no estoque para iniciar as operações da loja.</p>
          <button
            onClick={openAddModal}
            className="mt-4 inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-lg font-medium text-xs transition cursor-pointer"
          >
            Adicionar Primeiro Produto
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" id="products-grid">
          {filteredProducts.map(product => (
            <div
              key={product.id}
              className={`bg-white border rounded-3xl p-5 shadow-[0_8px_30px_rgb(0,0,0,0.015)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.035)] transition-all duration-300 relative group flex flex-col justify-between ${
                product.quantity === 0 
                  ? 'border-red-200 bg-red-50/10' 
                  : product.quantity <= 3 
                  ? 'border-amber-350 bg-amber-50/10 hover:border-amber-400' 
                  : 'border-[#E5E9EB]/65'
              }`}
              id={`product-card-${product.id}`}
            >
              <div>
                {/* Product Photo Box */}
                <div className="h-44 w-full bg-slate-50/50 rounded-2xl mb-4 overflow-hidden border border-slate-100 relative group-hover:scale-[1.01] transition-transform duration-300 flex items-center justify-center">
                  {product.image ? (
                    <img src={product.image} alt={product.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-300 space-y-1">
                      <ImageIcon className="w-8 h-8" />
                      <span className="text-[10px] font-medium uppercase tracking-wider font-mono">Sem Foto</span>
                    </div>
                  )}
                  {/* Stock counter overlay */}
                  <span className={`absolute top-3 right-3 text-xs font-bold px-2.5 py-1 rounded-full shadow-sm ${
                    product.quantity === 0 
                      ? 'bg-rose-100 text-rose-800 ring-2 ring-rose-200' 
                      : product.quantity <= 3 
                      ? 'bg-amber-100 text-amber-900 ring-2 ring-amber-200/50 animate-pulse' 
                      : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {product.quantity === 0 ? 'Sem estoque' : product.quantity <= 3 ? `Crítico: ${product.quantity} un` : `${product.quantity} un`}
                  </span>
                </div>

                {/* Title */}
                <h3 className="font-bold text-slate-800 text-base mb-1 truncate">{product.name}</h3>

                {/* Prices list */}
                <div className="space-y-1.5 py-2 my-2 border-y border-slate-50 text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Custo:</span>
                    <span className="font-medium text-slate-600">
                      {product.costPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Preço Mín.:</span>
                    <span className="font-bold text-slate-800">
                      {product.minSellPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px] pt-1">
                    <span className="text-emerald-500">Lucro Unitário Esperado:</span>
                    <span className="font-bold text-emerald-600">
                      {(product.minSellPrice - product.costPrice).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 mt-4 pt-2 border-t border-slate-50">
                <button
                  onClick={() => openEditModal(product)}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer"
                  title="Editar Produto"
                >
                  <Edit className="w-3.5 h-3.5" />
                  Editar
                </button>
                <button
                  onClick={() => setProductToDelete(product)}
                  className="bg-rose-50 hover:bg-rose-100 text-rose-600 p-2 rounded-lg text-xs font-medium transition cursor-pointer"
                  title="Deletar Produto"
                >
                  <Trash className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal - Cadastro e Edição */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" id="product-modal">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800">
                {editingId ? 'Editar Produto' : 'Cadastrar Novo Produto'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1" noValidate>
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Nome do Produto *</label>
                <input
                  type="text"
                  placeholder="Ex: Camiseta Polo Azul M"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors(prev => ({ ...prev, name: undefined }));
                  }}
                  className={`w-full bg-slate-50 border rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all ${
                    errors.name ? 'border-rose-400 focus:ring-rose-500 ring-1 ring-rose-200' : 'border-[#E5E9EB]'
                  }`}
                />
                {errors.name && (
                  <p className="text-rose-500 text-xs font-bold mt-1" id="error-product-name">{errors.name}</p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Quantidade *</label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={quantity === 0 ? '' : quantity}
                    onChange={(e) => {
                      setQuantity(Math.max(0, parseInt(e.target.value) || 0));
                      if (errors.quantity) setErrors(prev => ({ ...prev, quantity: undefined }));
                    }}
                    className={`w-full bg-slate-50 border rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all ${
                      errors.quantity ? 'border-rose-400 focus:ring-rose-500 ring-1 ring-rose-200' : 'border-slate-200'
                    }`}
                  />
                  {errors.quantity && (
                    <p className="text-rose-500 text-xs font-bold mt-1" id="error-product-qty">{errors.quantity}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Valor de Custo *</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0,00"
                    value={costPrice === 0 ? '' : costPrice}
                    onChange={(e) => {
                      setCostPrice(Math.max(0, parseFloat(e.target.value) || 0));
                      if (errors.costPrice) setErrors(prev => ({ ...prev, costPrice: undefined }));
                    }}
                    className={`w-full bg-slate-50 border rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all ${
                      errors.costPrice ? 'border-rose-400 focus:ring-rose-500 ring-1 ring-rose-200' : 'border-slate-200'
                    }`}
                  />
                  {errors.costPrice && (
                    <p className="text-rose-500 text-xs font-bold mt-1" id="error-product-cost">{errors.costPrice}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Preço Mín. Venda *</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0,00"
                    value={minSellPrice === 0 ? '' : minSellPrice}
                    onChange={(e) => {
                      setMinSellPrice(Math.max(0, parseFloat(e.target.value) || 0));
                      if (errors.minSellPrice) setErrors(prev => ({ ...prev, minSellPrice: undefined }));
                    }}
                    className={`w-full bg-slate-50 border rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white transition-all ${
                      errors.minSellPrice ? 'border-rose-400 focus:ring-rose-500 ring-1 ring-rose-200' : 'border-slate-200'
                    }`}
                  />
                  {errors.minSellPrice && (
                    <p className="text-rose-500 text-xs font-bold mt-1" id="error-product-min-price">{errors.minSellPrice}</p>
                  )}
                </div>
              </div>

              {/* Compression alert text */}
              {costPrice > 0 && minSellPrice > 0 && minSellPrice < costPrice && (
                <p className="text-xs text-rose-500 font-medium font-mono">
                  🚨 Atenção: O preço mínimo de venda é inferior ao custo de aquisição! Lucro será negativo.
                </p>
              )}

              {/* Photo Upload Area */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Foto do Produto (Opcional)</label>
                <div
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-300 flex flex-col items-center justify-center relative min-h-[140px] ${
                    dragActive 
                      ? 'border-indigo-600 bg-indigo-50/20 scale-95' 
                      : photoBase64 
                      ? 'border-emerald-200 bg-emerald-50/20' 
                      : 'border-slate-200 hover:border-slate-400 bg-slate-50/50 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                  />
                  
                  {photoBase64 ? (
                    <div className="relative group/img">
                      <img src={photoBase64} alt="Preview" className="w-24 h-24 object-cover rounded-lg border border-slate-100 shadow-sm" referrerPolicy="no-referrer" />
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setPhotoBase64('');
                        }}
                        className="absolute -top-2 -right-3 bg-rose-500 hover:bg-rose-600 text-white rounded-full p-1 shadow-sm transition"
                      >
                        <X className="w-3 h-3" />
                      </button>
                      <p className="text-xs text-emerald-600 mt-2 font-medium flex items-center justify-center gap-1">
                        <Check className="w-4.5 h-4.5" /> Foto carregada
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-1 text-slate-500 flex flex-col items-center">
                      <Camera className="w-8 h-8 text-slate-400" />
                      <p className="text-xs font-semibold">Arraste ou clique para enviar</p>
                      <p className="text-[10px] text-slate-400">Será compactada para caber no banco de dados local</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Form actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl px-4 py-2.5 font-medium transition text-sm cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl px-5 py-2.5 font-bold transition text-sm cursor-pointer shadow-sm"
                >
                  {editingId ? 'Salvar Alterações' : 'Adicionar Produto'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" id="confirm-delete-modal">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 w-full max-w-md overflow-hidden flex flex-col">
            <div className="p-6 text-center space-y-4">
              <div className="mx-auto w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
                <Trash className="w-6 h-6 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-bold text-slate-900">Confirmar Exclusão</h4>
                <p className="text-sm text-slate-500">
                  Tem certeza que deseja excluir o produto <strong className="text-slate-800">"{productToDelete.name}"</strong>?
                </p>
                <div className="text-xs text-rose-600 bg-rose-50 border border-rose-100 rounded-xl p-3 mt-2 text-left space-y-1">
                  <p className="font-bold">⚠️ Atenção:</p>
                  <p>Esta ação é irreversível e removerá permanentemente o produto do seu catálogo de estoque.</p>
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-xs font-semibold text-slate-750 hover:bg-slate-50 transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteProduct(productToDelete.id);
                  setProductToDelete(null);
                }}
                className="bg-rose-600 hover:bg-rose-700 text-white px-5 py-2 rounded-xl text-xs font-bold shadow-sm transition-all cursor-pointer"
              >
                Sim, Excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
