import React, { useState, useEffect } from 'react';
import { Product, Sale, Expense, PartnerSplit, ShopSettings } from './types';
import DashboardTab from './components/DashboardTab';
import EstoqueTab from './components/EstoqueTab';
import VendasTab from './components/VendasTab';
import HistoricoTab from './components/HistoricoTab';
import FinanceiroTab from './components/FinanceiroTab';
import SociosTab from './components/SociosTab';
import RelatoriosTab from './components/RelatoriosTab';
import { 
  BarChart3, 
  Package, 
  ShoppingBag, 
  ClipboardList, 
  Receipt, 
  Users, 
  FileDown, 
  Store,
  Menu,
  X
} from 'lucide-react';

// Seed data to make the app beautiful and instantly interactive is highly recommended!
const initialProducts: Product[] = [
  {
    id: "p1",
    name: "Camiseta Básica Premium",
    quantity: 35,
    costPrice: 22.50,
    minSellPrice: 49.90,
  },
  {
    id: "p2",
    name: "Calça Jeans Slim Blue",
    quantity: 18,
    costPrice: 48.00,
    minSellPrice: 99.90,
  },
  {
    id: "p3",
    name: "Boné Trucker Classic Black",
    quantity: 25,
    costPrice: 12.00,
    minSellPrice: 29.90,
  },
  {
    id: "p4",
    name: "Jaqueta Corta Vento Sport",
    quantity: 3, // Low stock on purpose to trigger dashboard alerts!
    costPrice: 65.00,
    minSellPrice: 139.90,
  }
];

const initialSales: Sale[] = [
  {
    id: "S001",
    timestamp: "2026-06-10T14:30:00.000Z",
    productId: "p1",
    productName: "Camiseta Básica Premium",
    quantity: 2,
    soldPrice: 55.00, // Sold for more than minSellPrice
    clientName: "Roberto Alencar",
    clientPhone: "(11) 98765-4321"
  },
  {
    id: "S002",
    timestamp: "2026-06-11T16:15:00.000Z",
    productId: "p2",
    productName: "Calça Jeans Slim Blue",
    quantity: 1,
    soldPrice: 110.00,
    clientName: "Amanda Rodrigues",
    clientPhone: "(21) 99911-2233"
  },
  {
    id: "S003",
    timestamp: "2026-06-14T10:00:00.000Z",
    productId: "p3",
    productName: "Boné Trucker Classic Black",
    quantity: 1,
    soldPrice: 29.90,
    clientName: "José da Silva",
    clientPhone: "(11) 94433-2211"
  }
];

const initialExpenses: Expense[] = [
  {
    id: "e1",
    timestamp: "2026-06-05T12:00:00.000Z",
    description: "Conta de Energia Elétrica",
    value: 280.00,
    category: "Contas de Consumo (Luz, Net, Água)"
  },
  {
    id: "e2",
    timestamp: "2026-06-08T12:00:00.050Z",
    description: "Internet Fibra Óptica 300Mb",
    value: 119.90,
    category: "Contas de Consumo (Luz, Net, Água)"
  },
  {
    id: "e3",
    timestamp: "2026-06-11T12:00:00.100Z",
    description: "Embalagens de papel Kraft (Pacote com 100)",
    value: 85.00,
    category: "Embalagens"
  }
];

const initialPartnerSplit: PartnerSplit = {
  pedroPercent: 50,
  thalissonPercent: 50
};

const initialShopSettings: ShopSettings = {
  shopName: "ST Imports",
  shopPhone: "(11) 93322-1100",
  address: "Av. Paulista, 1000 - Bela Vista, São Paulo - SP",
  cnpj: "12.345.678/0001-90"
};

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Core state variables
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [partnerSplit, setPartnerSplit] = useState<PartnerSplit>(initialPartnerSplit);
  const [shopSettings, setShopSettings] = useState<ShopSettings>(initialShopSettings);
  
  // Modal for displaying a receipt from anywhere
  const [selectedReceiptSale, setSelectedReceiptSale] = useState<Sale | null>(null);

  // Initialize and load from LocalStorage to support permanent offline persistence
  useEffect(() => {
    const savedProducts = localStorage.getItem('loja_products');
    const savedSales = localStorage.getItem('loja_sales');
    const savedExpenses = localStorage.getItem('loja_expenses');
    const savedSplit = localStorage.getItem('loja_split');
    const savedSettings = localStorage.getItem('loja_settings');

    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    } else {
      setProducts(initialProducts);
      localStorage.setItem('loja_products', JSON.stringify(initialProducts));
    }

    if (savedSales) {
      setSales(JSON.parse(savedSales));
    } else {
      setSales(initialSales);
      localStorage.setItem('loja_sales', JSON.stringify(initialSales));
    }

    if (savedExpenses) {
      setExpenses(JSON.parse(savedExpenses));
    } else {
      setExpenses(initialExpenses);
      localStorage.setItem('loja_expenses', JSON.stringify(initialExpenses));
    }

    if (savedSplit) {
      setPartnerSplit(JSON.parse(savedSplit));
    } else {
      setPartnerSplit(initialPartnerSplit);
      localStorage.setItem('loja_split', JSON.stringify(initialPartnerSplit));
    }

    if (savedSettings) {
      const parsed = JSON.parse(savedSettings);
      let upgraded = false;
      if (parsed.shopName === "Estilo Urbano Store") {
        parsed.shopName = "ST Imports";
        upgraded = true;
      }
      if (!parsed.cnpj) {
        parsed.cnpj = "12.345.678/0001-90";
        upgraded = true;
      }
      if (!parsed.address) {
        parsed.address = "Av. Paulista, 1000 - Bela Vista, São Paulo - SP";
        upgraded = true;
      }
      setShopSettings(parsed);
      if (upgraded) {
        localStorage.setItem('loja_settings', JSON.stringify(parsed));
      }
    } else {
      setShopSettings(initialShopSettings);
      localStorage.setItem('loja_settings', JSON.stringify(initialShopSettings));
    }
  }, []);

  // Sync helpers to keep localstorage updated
  const updateLocalStorage = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  // Add Product
  const handleAddProduct = (newProduct: Omit<Product, 'id'>) => {
    const prod: Product = {
      id: Math.random().toString(36).substring(2, 9),
      ...newProduct
    };
    const updated = [...products, prod];
    setProducts(updated);
    updateLocalStorage('loja_products', updated);
  };

  // Edit Product
  const handleEditProduct = (id: string, updatedFields: Partial<Product>) => {
    const updated = products.map(p => p.id === id ? { ...p, ...updatedFields } : p);
    setProducts(updated);
    updateLocalStorage('loja_products', updated);
  };

  // Delete Product
  const handleDeleteProduct = (id: string) => {
    const updated = products.filter(p => p.id !== id);
    setProducts(updated);
    updateLocalStorage('loja_products', updated);
  };

  // Add Sale and Automatically Subtract Stock
  const handleAddSale = (newSale: Omit<Sale, 'id' | 'timestamp'>) => {
    const sale: Sale = {
      id: "S" + Math.random().toString(36).substring(2, 6).toUpperCase(),
      timestamp: new Date().toISOString(),
      ...newSale
    };

    // 1. Subtract available inventory stock
    const updatedProducts = products.map(p => {
      if (p.id === sale.productId) {
        return {
          ...p,
          quantity: Math.max(0, p.quantity - sale.quantity)
        };
      }
      return p;
    });

    setProducts(updatedProducts);
    updateLocalStorage('loja_products', updatedProducts);

    // 2. Add sales data log
    const updatedSales = [...sales, sale];
    setSales(updatedSales);
    updateLocalStorage('loja_sales', updatedSales);
  };

  // Add Expense
  const handleAddExpense = (newExpense: Omit<Expense, 'id' | 'timestamp'>) => {
    const expense: Expense = {
      id: "E" + Math.random().toString(36).substring(2, 6).toUpperCase(),
      timestamp: new Date().toISOString(),
      ...newExpense
    };
    const updated = [...expenses, expense];
    setExpenses(updated);
    updateLocalStorage('loja_expenses', updated);
  };

  // Delete Expense
  const handleDeleteExpense = (id: string) => {
    const updated = expenses.filter(e => e.id !== id);
    setExpenses(updated);
    updateLocalStorage('loja_expenses', updated);
  };

  // Delete/Cancel Sale (and restore inventory stock)
  const handleDeleteSale = (saleId: string) => {
    const saleToCancel = sales.find(s => s.id === saleId);
    if (!saleToCancel) return;

    // Restore stock
    const updatedProducts = products.map(p => {
      if (p.id === saleToCancel.productId) {
        return {
          ...p,
          quantity: p.quantity + saleToCancel.quantity
        };
      }
      return p;
    });
    setProducts(updatedProducts);
    updateLocalStorage('loja_products', updatedProducts);

    // Remove sale
    const updatedSales = sales.filter(s => s.id !== saleId);
    setSales(updatedSales);
    updateLocalStorage('loja_sales', updatedSales);
  };

  // Update societer splits
  const handleUpdatePartnerSplit = (newSplit: PartnerSplit) => {
    setPartnerSplit(newSplit);
    updateLocalStorage('loja_split', newSplit);
  };

  // Update shop header settings
  const handleUpdateShopSettings = (newSettings: ShopSettings) => {
    setShopSettings(newSettings);
    updateLocalStorage('loja_settings', newSettings);
  };

  // Active view router mapping
  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardTab 
            products={products} 
            sales={sales} 
            expenses={expenses} 
          />
        );
      case 'estoque':
        return (
          <EstoqueTab 
            products={products}
            onAddProduct={handleAddProduct}
            onEditProduct={handleEditProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        );
      case 'vendas':
        return (
          <VendasTab 
            products={products}
            shopSettings={shopSettings}
            onAddSale={handleAddSale}
            onShowReceipt={(sale) => {
              setSelectedReceiptSale(sale);
              setActiveTab('historico'); // move to history to show receipt
            }}
          />
        );
      case 'historico':
        return (
          <HistoricoTab 
            sales={sales}
            shopSettings={shopSettings}
            onUpdateShopSettings={handleUpdateShopSettings}
            selectedReceiptSale={selectedReceiptSale}
            onCloseReceipt={() => setSelectedReceiptSale(null)}
            onOpenReceipt={(sale) => setSelectedReceiptSale(sale)}
            onDeleteSale={handleDeleteSale}
          />
        );
      case 'financeiro':
        return (
          <FinanceiroTab 
            expenses={expenses}
            onAddExpense={handleAddExpense}
            onDeleteExpense={handleDeleteExpense}
          />
        );
      case 'socios':
        return (
          <SociosTab 
            products={products}
            sales={sales}
            expenses={expenses}
            partnerSplit={partnerSplit}
            onUpdatePartnerSplit={handleUpdatePartnerSplit}
          />
        );
      case 'relatorios':
        return (
          <RelatoriosTab 
            products={products}
            sales={sales}
            expenses={expenses}
          />
        );
      default:
        return <div className="text-center p-8">Aba não encontrada.</div>;
    }
  };

  // Navigation catalog
  const navigationItems = [
    { id: 'dashboard', label: 'Painel Geral', icon: BarChart3 },
    { id: 'estoque', label: 'Estoque & Catálogo', icon: Package },
    { id: 'vendas', label: 'Realizar Venda', icon: ShoppingBag },
    { id: 'historico', label: 'Vendas & Cupons', icon: ClipboardList },
    { id: 'financeiro', label: 'Despesas & Custos', icon: Receipt },
    { id: 'socios', label: 'Sócios & Lucros', icon: Users },
    { id: 'relatorios', label: 'Relatórios Mensais', icon: FileDown },
  ];

  return (
    <div className="min-h-screen bg-[#F4F7F9] flex flex-col lg:flex-row font-sans antialiased text-slate-800">
      
      {/* LEFT NAVIGATION SIDEBAR - Visible only on Desktop (lg and up) */}
      <aside className="hidden lg:flex w-72 bg-white border-r border-[#E5E9EB] min-h-screen flex-col justify-between sticky top-0 p-6 no-print shadow-[rgba(0,0,0,0.01)_1px_0_0_0]" id="desktop-sidebar">
        <div className="flex flex-col gap-8">
          {/* Brand Logo Box */}
          <div className="flex items-center gap-3 px-2 py-1">
            <div className="bg-indigo-600 text-white p-2.5 rounded-2xl shadow-md shadow-indigo-100">
              <Store className="w-5 h-5" />
            </div>
            <div className="overflow-hidden">
              <h1 className="text-sm font-bold text-slate-900 tracking-tight truncate">{shopSettings.shopName}</h1>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest font-mono">Controladoria v1.0</p>
            </div>
          </div>

          {/* Navigation Items list */}
          <nav className="flex flex-col gap-1.5" id="sidebar-nav">
            {navigationItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold tracking-wide transition-all duration-200 cursor-pointer text-left ${
                    isActive 
                      ? 'bg-indigo-50/70 text-indigo-700 font-bold' 
                      : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 transition-transform duration-200 ${isActive ? 'text-indigo-600 scale-110' : 'text-slate-400'}`} />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer with system credentials */}
        <div className="pt-4 border-t border-slate-100 px-2">
          <p className="text-[10px] text-slate-400 font-medium">© {new Date().getFullYear()} {shopSettings.shopName}</p>
          <p className="text-[9px] font-mono text-slate-300 mt-0.5">Offline-first (LocalStorage)</p>
        </div>
      </aside>

      {/* MOBILE HEADER - Visible on screens below lg (tablets & mobile) */}
      <header className="lg:hidden bg-white border-b border-[#E5E9EB] sticky top-0 z-30 no-print shadow-xs" id="mobile-app-header">
        <div className="px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 text-white p-2 rounded-xl">
              <Store className="w-4 h-4" />
            </div>
            <div>
              <h1 className="text-xs font-bold text-slate-900 tracking-tight">{shopSettings.shopName}</h1>
              <p className="text-[8px] text-slate-400 font-bold uppercase tracking-widest font-mono">Controladoria v1.0</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Mobile Label for active tab */}
            <span className="text-[10px] font-mono uppercase bg-indigo-50 text-indigo-700 px-2 py-1 rounded-md font-bold">
              {navigationItems.find(n => n.id === activeTab)?.label}
            </span>
            
            {/* Mobile menu trigger button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer"
              aria-label="Abrir menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer Navigation Menu */}
        {mobileMenuOpen && (
          <div className="fixed inset-y-0 inset-x-0 top-[53px] bg-slate-900/20 backdrop-blur-xs z-50 no-print" onClick={() => setMobileMenuOpen(false)}>
            <div 
              className="bg-white border-b border-slate-200 p-4 shadow-xl flex flex-col gap-1 ease-in duration-150 animate-in fade-in"
              onClick={(e) => e.stopPropagation()}
            >
              {navigationItems.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-3.5 px-4 py-3 rounded-lg text-xs font-bold text-left transition cursor-pointer ${
                      isActive 
                        ? 'bg-indigo-50/70 text-indigo-700' 
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </header>

      {/* MAIN WORKSPACE WRAPPER */}
      <div className="flex-1 flex flex-col min-h-screen overflow-x-hidden">
        
        {/* Workspace Content flow */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {renderTabContent()}
        </main>

        {/* Mobile-only footer - Hidden on desktop layout */}
        <footer className="lg:hidden bg-white border-t border-[#E5E9EB] py-6 text-center text-[11px] text-slate-400 no-print" id="mobile-app-footer">
          <div className="px-4">
            <p>© {new Date().getFullYear()} {shopSettings.shopName}</p>
            <p className="mt-1 font-mono text-[9px] text-slate-300">Padrão SPA Offline First</p>
          </div>
        </footer>

      </div>
    </div>
  );
}
