export interface Product {
  id: string;
  name: string;
  quantity: number;
  costPrice: number;
  minSellPrice: number;
  image?: string; // base64 string or placeholder URL
}

export interface Sale {
  id: string;
  timestamp: string; // ISO string
  productId: string;
  productName: string;
  quantity: number;
  soldPrice: number;
  clientName: string;
  clientPhone: string;
}

export interface Expense {
  id: string;
  timestamp: string; // ISO string
  description: string;
  value: number;
  category: string;
}

export interface PartnerSplit {
  pedroPercent: number;
  thalissonPercent: number;
}

export interface ShopSettings {
  shopName: string;
  shopPhone: string;
  cnpj?: string;
  address?: string;
}
